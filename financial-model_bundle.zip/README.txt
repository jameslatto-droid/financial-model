Financial Model — local run (requires Node.js)
1) Open a terminal in this folder.
2) On macOS/Linux:  bash start.sh
   On Windows:      start.bat
3) Then visit http://localhost:5173
