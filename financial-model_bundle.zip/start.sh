#!/usr/bin/env bash
set -e
npx --yes serve -s dist -l 5173
